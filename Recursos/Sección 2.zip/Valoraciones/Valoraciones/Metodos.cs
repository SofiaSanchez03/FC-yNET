﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valoraciones
{
    class Metodos
    {
        public void MetodoEjmeplo(int i,string s,float f)
        {
               valor = i;
        }

        void MetodoEjmeplo(int i,float f)
        {
            valor = i;
        }
        void MetodoEjmeplo()
        {
            valor = 5;
        }

        int valor = 0;
    }
}
