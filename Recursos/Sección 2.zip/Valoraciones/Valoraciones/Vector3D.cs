﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valoraciones
{
    public struct Vector3D
    {
        public float x;
        public float y;
        public float z;

    }
}
