﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valoraciones.EstructurasDeControl
{
    class Estados
    {
        /*
        // Estado declaracion
        int contador;

        // Estado de asignación
        contador = 1 + 1 +5 +algunaVariable;

      
        // Estado declaracion con inicializadores  
        int[] arrayEnteros = { 15, 32, 108, 74, 9 }; 
       

        // Bloques de código multiples estados 
        foreach (int entero in arrayEnteros)
        {
            // Haz lo que sea...
        }



        // Estado de invocación
        Hola();

        

        // Estado de expresion
            contador ++;

        */


        /// Tipos de estados mas usados
        /// - Decalaración 
        /// - Expresión  (contador ++)
        /// - Selección (if then else, switch case)
        /// - Iteración o Bucle 
        /// - Salto
        /// - Excepción

    }
}
