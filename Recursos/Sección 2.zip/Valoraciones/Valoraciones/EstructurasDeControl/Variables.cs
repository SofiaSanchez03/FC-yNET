﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Valoraciones.EstructurasDeControl
{
    class Variables
    {

        // Tipo valor
        /*
        double = 0,123456123456;
        enum {none,norte,sur,este,oeste}
        float miFloat;
        int = 666;

        Char miChar = "Hola Mundo";
        miChar.

        bool miBool = true;
        bool miBool = false;

        // Menos comunes para opreaciones mas complejas 
            o manejo datos mas puntuales

        long
        sbyte
        short
        struct
        uint
        ulong
        ushort
        */


        // Variables tipo referencia
        /*

        class (  MiClase variableDeMiClase = new  MiClase() )
        
        string miCadena = "Hola mundo";



        delegate
        dynamic
        interface
        object
        Interpolated Strings

         */

        // https://msdn.microsoft.com/en-us/library/490f96s2.aspx
    }
}
