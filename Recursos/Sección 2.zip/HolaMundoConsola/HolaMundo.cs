using System;

public class Program
{
	static void Main()
	{
		Console.WriteLine(DateTime.Now.DayOfWeek);
	}
}