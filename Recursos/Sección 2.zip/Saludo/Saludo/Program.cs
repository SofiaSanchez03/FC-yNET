﻿using System;

namespace Saludo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola " + args[0] + " " + args[1]);
        }
    }
}


